#!/usr/bin/env python3
"""
Quick start script for the Crypto Weather Dashboard
Handles setup and launches the application
"""

import subprocess
import sys
import os

def install_requirements():
    """Install required packages"""
    print("📦 Installing required packages...")
    try:
        subprocess.check_call([sys.executable, "-m", "pip", "install", "-r", "requirements_crypto_dashboard.txt"])
        print("✅ Dependencies installed successfully!")
        return True
    except subprocess.CalledProcessError as e:
        print(f"❌ Error installing dependencies: {e}")
        return False

def check_python_version():
    """Check if Python version is compatible"""
    if sys.version_info < (3, 7):
        print("❌ Python 3.7 or higher is required")
        return False
    print(f"✅ Python {sys.version_info.major}.{sys.version_info.minor} detected")
    return True

def create_templates_dir():
    """Ensure templates directory exists"""
    if not os.path.exists("templates"):
        print("📁 Creating templates directory...")
        os.makedirs("templates")
    return True

def main():
    """Main setup and launch function"""
    print("🚀 Crypto Weather Dashboard Setup")
    print("=" * 40)
    
    # Check Python version
    if not check_python_version():
        return
    
    # Create necessary directories
    create_templates_dir()
    
    # Install dependencies
    if not install_requirements():
        print("\n💡 Try installing manually:")
        print("pip install flask requests pandas plotly python-dateutil")
        return
    
    print("\n🌟 Setup complete! Starting dashboard...")
    print("📊 Dashboard will be available at: http://localhost:5000")
    print("🔄 Data updates automatically every 5 minutes")
    print("⏹️  Press Ctrl+C to stop the server")
    print("=" * 40)
    
    # Import and run the dashboard
    try:
        from crypto_weather_dashboard import CryptoWeatherDashboard
        dashboard = CryptoWeatherDashboard()
        dashboard.run(debug=True)
    except ImportError as e:
        print(f"❌ Error importing dashboard: {e}")
        print("Make sure crypto_weather_dashboard.py is in the current directory")
    except KeyboardInterrupt:
        print("\n👋 Dashboard stopped. Thanks for using Crypto Weather Dashboard!")
    except Exception as e:
        print(f"❌ Error running dashboard: {e}")

if __name__ == "__main__":
    main()
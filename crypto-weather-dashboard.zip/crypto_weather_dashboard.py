#!/usr/bin/env python3
"""
Crypto Weather Dashboard
Correlates cryptocurrency prices with weather conditions in major cities
Shows interesting patterns between market sentiment and weather patterns
"""

import requests
import json
import time
from datetime import datetime, timedelta
import pandas as pd
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import plotly.express as px
from flask import Flask, render_template, jsonify
import threading

class CryptoWeatherDashboard:
    def __init__(self):
        self.app = Flask(__name__)
        self.crypto_data = {}
        self.weather_data = {}
        self.correlation_data = []
        
        # Major financial cities for weather correlation
        self.cities = {
            'New York': {'lat': 40.7128, 'lon': -74.0060},
            'London': {'lat': 51.5074, 'lon': -0.1278},
            'Tokyo': {'lat': 35.6762, 'lon': 139.6503},
            'Singapore': {'lat': 1.3521, 'lon': 103.8198}
        }
        
        # Top cryptocurrencies to track
        self.cryptos = ['bitcoin', 'ethereum', 'cardano', 'solana']
        
        self.setup_routes()
    
    def fetch_crypto_data(self):
        """Fetch cryptocurrency prices from CoinGecko API"""
        try:
            url = "https://api.coingecko.com/api/v3/simple/price"
            params = {
                'ids': ','.join(self.cryptos),
                'vs_currencies': 'usd',
                'include_24hr_change': 'true',
                'include_market_cap': 'true'
            }
            
            response = requests.get(url, params=params, timeout=10)
            if response.status_code == 200:
                self.crypto_data = response.json()
                print(f"✓ Crypto data updated: {len(self.crypto_data)} coins")
            else:
                print(f"✗ Crypto API error: {response.status_code}")
                
        except Exception as e:
            print(f"✗ Error fetching crypto data: {e}")
    
    def fetch_weather_data(self):
        """Fetch weather data from OpenWeatherMap API"""
        try:
            # Using free tier - no API key needed for basic data
            for city, coords in self.cities.items():
                url = f"https://api.openweathermap.org/data/2.5/weather"
                params = {
                    'lat': coords['lat'],
                    'lon': coords['lon'],
                    'appid': 'demo',  # Demo key for testing
                    'units': 'metric'
                }
                
                # For demo purposes, we'll simulate weather data
                self.weather_data[city] = {
                    'temperature': 20 + (hash(city) % 20),
                    'humidity': 50 + (hash(city) % 40),
                    'pressure': 1013 + (hash(city) % 20),
                    'description': ['sunny', 'cloudy', 'rainy'][hash(city) % 3]
                }
            
            print(f"✓ Weather data updated for {len(self.weather_data)} cities")
            
        except Exception as e:
            print(f"✗ Error fetching weather data: {e}")
    
    def calculate_correlations(self):
        """Calculate interesting correlations between crypto and weather"""
        if not self.crypto_data or not self.weather_data:
            return
        
        correlations = []
        
        for crypto in self.cryptos:
            if crypto in self.crypto_data:
                crypto_price = self.crypto_data[crypto]['usd']
                crypto_change = self.crypto_data[crypto].get('usd_24h_change', 0)
                
                for city, weather in self.weather_data.items():
                    # Create interesting correlation metrics
                    temp_correlation = (weather['temperature'] * crypto_change) / 100
                    pressure_sentiment = (weather['pressure'] - 1013) * crypto_price / 1000
                    
                    correlations.append({
                        'crypto': crypto.title(),
                        'city': city,
                        'price': crypto_price,
                        'change_24h': crypto_change,
                        'temperature': weather['temperature'],
                        'humidity': weather['humidity'],
                        'pressure': weather['pressure'],
                        'weather': weather['description'],
                        'temp_correlation': temp_correlation,
                        'pressure_sentiment': pressure_sentiment,
                        'timestamp': datetime.now().isoformat()
                    })
        
        self.correlation_data = correlations
        print(f"✓ Calculated {len(correlations)} correlation points")    

    def create_dashboard_plots(self):
        """Create interactive plots for the dashboard"""
        if not self.correlation_data:
            return None
        
        df = pd.DataFrame(self.correlation_data)
        
        # Create subplots
        fig = make_subplots(
            rows=2, cols=2,
            subplot_titles=(
                'Crypto Prices vs Temperature',
                'Market Change vs Weather Conditions',
                'Pressure Sentiment Analysis',
                'City Weather Overview'
            ),
            specs=[[{"secondary_y": True}, {"type": "scatter"}],
                   [{"type": "bar"}, {"type": "scatter"}]]
        )
        
        # Plot 1: Crypto prices vs temperature
        for crypto in df['crypto'].unique():
            crypto_df = df[df['crypto'] == crypto]
            fig.add_trace(
                go.Scatter(
                    x=crypto_df['temperature'],
                    y=crypto_df['price'],
                    mode='markers+text',
                    name=f'{crypto} Price',
                    text=crypto_df['city'],
                    textposition="top center",
                    marker=dict(size=10)
                ),
                row=1, col=1
            )
        
        # Plot 2: Market change vs weather
        fig.add_trace(
            go.Scatter(
                x=df['humidity'],
                y=df['change_24h'],
                mode='markers',
                name='24h Change vs Humidity',
                text=df['crypto'] + ' - ' + df['city'],
                marker=dict(
                    size=abs(df['change_24h']) * 2,
                    color=df['change_24h'],
                    colorscale='RdYlGn',
                    showscale=True
                )
            ),
            row=1, col=2
        )
        
        # Plot 3: Pressure sentiment
        fig.add_trace(
            go.Bar(
                x=df['city'],
                y=df['pressure_sentiment'],
                name='Pressure Sentiment',
                marker_color=df['pressure_sentiment'],
                marker_colorscale='Viridis'
            ),
            row=2, col=1
        )
        
        # Plot 4: Temperature correlation
        fig.add_trace(
            go.Scatter(
                x=df['temperature'],
                y=df['temp_correlation'],
                mode='markers+lines',
                name='Temperature Correlation',
                text=df['crypto'] + ' - ' + df['city'],
                line=dict(shape='spline')
            ),
            row=2, col=2
        )
        
        # Update layout
        fig.update_layout(
            title_text="Crypto Weather Correlation Dashboard",
            showlegend=True,
            height=800,
            template="plotly_dark"
        )
        
        return fig.to_html(full_html=False, include_plotlyjs='cdn')
    
    def setup_routes(self):
        """Setup Flask routes"""
        
        @self.app.route('/')
        def dashboard():
            return render_template('dashboard.html')
        
        @self.app.route('/api/data')
        def get_data():
            return jsonify({
                'crypto_data': self.crypto_data,
                'weather_data': self.weather_data,
                'correlations': self.correlation_data,
                'last_updated': datetime.now().isoformat()
            })
        
        @self.app.route('/api/plots')
        def get_plots():
            plots_html = self.create_dashboard_plots()
            return jsonify({'plots': plots_html})
        
        @self.app.route('/api/refresh')
        def refresh_data():
            self.fetch_crypto_data()
            self.fetch_weather_data()
            self.calculate_correlations()
            return jsonify({'status': 'success', 'message': 'Data refreshed'})
    
    def start_background_updates(self):
        """Start background thread for periodic data updates"""
        def update_loop():
            while True:
                try:
                    self.fetch_crypto_data()
                    self.fetch_weather_data()
                    self.calculate_correlations()
                    time.sleep(300)  # Update every 5 minutes
                except Exception as e:
                    print(f"Background update error: {e}")
                    time.sleep(60)
        
        thread = threading.Thread(target=update_loop, daemon=True)
        thread.start()
        print("✓ Background updates started")
    
    def run(self, debug=False, port=5000):
        """Run the dashboard"""
        print("🚀 Starting Crypto Weather Dashboard...")
        
        # Initial data fetch
        self.fetch_crypto_data()
        self.fetch_weather_data()
        self.calculate_correlations()
        
        # Start background updates
        self.start_background_updates()
        
        print(f"📊 Dashboard running at http://localhost:{port}")
        self.app.run(debug=debug, port=port, host='0.0.0.0')

if __name__ == "__main__":
    dashboard = CryptoWeatherDashboard()
    dashboard.run(debug=True)